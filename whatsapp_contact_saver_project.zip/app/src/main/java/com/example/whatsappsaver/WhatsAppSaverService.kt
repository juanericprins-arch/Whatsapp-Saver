package com.example.whatsappsaver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log
import android.os.Handler
import android.os.Looper

class WhatsAppSaverService : AccessibilityService() {

    private val TAG = "WhatsAppSaverService"
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())
    
    // State machine for automation
    private enum class State { IDLE, IN_CHAT_LIST, IN_CHAT, IN_PROFILE, SAVING }
    private var currentState = State.IDLE

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val rootNode = rootInActiveWindow ?: return
        
        // Simple logic: if we are in WhatsApp, try to find unsaved numbers
        val packageName = event.packageName?.toString() ?: ""
        if (packageName.contains("whatsapp")) {
            autoSaveProcess(rootNode)
        }
    }

    private fun autoSaveProcess(rootNode: AccessibilityNodeInfo) {
        // 1. Find all phone numbers on screen (chats that aren't saved)
        val nodesWithNumbers = findNodesByRegex(rootNode, Regex("""\+\d{1,3}\s?\d+"""))
        
        if (nodesWithNumbers.isNotEmpty()) {
            val targetChat = nodesWithNumbers[0]
            Log.d(TAG, "Found unsaved contact: ${targetChat.text}")
            
            // 2. Click the chat to open it
            targetChat.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            
            // 3. Wait a bit, then click the profile header
            handler.postDelayed({
                clickProfileHeader()
            }, 1000)
        }
    }

    private fun clickProfileHeader() {
        val rootNode = rootInActiveWindow ?: return
        // Usually the top bar has the name/number. We click the top area.
        val dispatchStatus = dispatchGesture(createClickGesture(500f, 100f), null, null)
        Log.d(TAG, "Clicked profile header: $dispatchStatus")
        
        // 4. Wait for profile to open, then find "Save"
        handler.postDelayed({
            findAndClickSave()
        }, 1500)
    }

    private fun findAndClickSave() {
        val rootNode = rootInActiveWindow ?: return
        // Look for buttons with text "Save", "Add to contacts", etc.
        val saveButtons = rootNode.findAccessibilityNodeInfosByText("Save")
        if (saveButtons.isNotEmpty()) {
            saveButtons[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Log.d(TAG, "Clicked Save button")
        } else {
            // Try common WhatsApp Business IDs or alternative text
            val addButtons = rootNode.findAccessibilityNodeInfosByText("Add to contacts")
            if (addButtons.isNotEmpty()) {
                addButtons[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
    }

    private fun findNodesByRegex(node: AccessibilityNodeInfo, regex: Regex): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        if (node.text != null && regex.containsMatchIn(node.text)) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                result.addAll(findNodesByRegex(child, regex))
            }
        }
        return result
    }

    private fun createClickGesture(x: Float, y: Float): GestureDescription {
        val path = Path()
        path.moveTo(x, y)
        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, 100))
        return builder.build()
    }

    override fun onInterrupt() {
        isRunning = false
    }
}
